--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9
-- Dumped by pg_dump version 10.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public."ParkingEntry" DROP CONSTRAINT un_vehnumber;
ALTER TABLE ONLY public."ParkingSlot" DROP CONSTRAINT "ParkingSlot_pkey";
ALTER TABLE ONLY public."ParkingEntry" DROP CONSTRAINT "ParkingEntry_pkey";
DROP TABLE public."ParkingSlot";
DROP TABLE public."ParkingEntry";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ParkingEntry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ParkingEntry" (
    entryid character varying(30) NOT NULL,
    slotid character varying(10) NOT NULL,
    vehiclenumber integer NOT NULL,
    timein date NOT NULL,
    timeout date,
    amount money
);


ALTER TABLE public."ParkingEntry" OWNER TO postgres;

--
-- Name: ParkingSlot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ParkingSlot" (
    slotid character varying(10) NOT NULL,
    index integer NOT NULL,
    floor integer NOT NULL,
    vehicletype character varying(20) NOT NULL,
    cost money NOT NULL,
    occupied boolean NOT NULL,
    currententryid text
);


ALTER TABLE public."ParkingSlot" OWNER TO postgres;

--
-- Data for Name: ParkingEntry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ParkingEntry" (entryid, slotid, vehiclenumber, timein, timeout, amount) FROM stdin;
\.
COPY public."ParkingEntry" (entryid, slotid, vehiclenumber, timein, timeout, amount) FROM '$$PATH$$/2800.dat';

--
-- Data for Name: ParkingSlot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ParkingSlot" (slotid, index, floor, vehicletype, cost, occupied, currententryid) FROM stdin;
\.
COPY public."ParkingSlot" (slotid, index, floor, vehicletype, cost, occupied, currententryid) FROM '$$PATH$$/2801.dat';

--
-- Name: ParkingEntry ParkingEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingEntry"
    ADD CONSTRAINT "ParkingEntry_pkey" PRIMARY KEY (entryid);


--
-- Name: ParkingSlot ParkingSlot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingSlot"
    ADD CONSTRAINT "ParkingSlot_pkey" PRIMARY KEY (slotid);


--
-- Name: ParkingEntry un_vehnumber; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingEntry"
    ADD CONSTRAINT un_vehnumber UNIQUE (vehiclenumber);


--
-- PostgreSQL database dump complete
--

